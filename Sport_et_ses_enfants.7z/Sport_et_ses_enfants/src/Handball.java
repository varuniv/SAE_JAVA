public class Handball extends Sport{
    public Handball(String nom, boolean collectif, int nbJoueur) {
        super(nom, collectif, nbJoueur);
    }
}
