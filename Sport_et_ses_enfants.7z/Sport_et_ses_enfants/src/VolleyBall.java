public class VolleyBall extends Sport {
    public VolleyBall(String nom, boolean collectif, int nbJoueur) {
        super(nom, collectif, nbJoueur);
    }
}
