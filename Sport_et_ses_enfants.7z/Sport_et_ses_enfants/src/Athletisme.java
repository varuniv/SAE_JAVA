public class Athletisme extends Sport{
    private int distance;

    public Athletisme(String nom, boolean collectif, int nbJoueur, int distance) {
        super(nom, collectif, nbJoueur);
    }

    public int getDistance() {
        return this.distance;
    }
}
